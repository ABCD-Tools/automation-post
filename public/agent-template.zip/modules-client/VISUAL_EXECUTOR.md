# Visual Action Executor - Documentation

## Overview

The `VisualActionExecutor` class executes recorded actions using visual data (screenshots, text, positions) instead of relying solely on DOM selectors. This makes playback robust against UI changes.

## Execution Strategy

The executor tries multiple methods in order of speed vs. robustness:

```
1. Backup Selector (Fast Path)
   ├─ Try selector from recording
   ├─ Verify element text matches
   └─ Execute if found and verified
   
2. Visual Search (Robust Path)
   ├─ Find elements by text content
   ├─ Filter by position (±15% tolerance)
   ├─ If multiple matches: compare screenshots
   └─ Execute on best match (≥70% similarity)
   
3. Position Click (Last Resort)
   ├─ Click at recorded coordinates
   ├─ Add random offset (±2px)
   └─ Human-like behavior (hover first)
```

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│              VisualActionExecutor                        │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  executeAction(action)                                   │
│    ├─→ trySelector(action)                              │
│    │    ├─ waitForSelector(backup_selector)             │
│    │    ├─ Verify text matches                          │
│    │    └─ Execute (click/type)                         │
│    │                                                     │
│    ├─→ findByVisual(action)                             │
│    │    ├─ findByText(visual.text)                      │
│    │    │    └─ Search DOM for matching text            │
│    │    │                                                │
│    │    ├─ filterByPosition(candidates, visual.position)│
│    │    │    └─ Keep only elements near recorded pos    │
│    │    │                                                │
│    │    ├─ findBestVisualMatch(candidates, screenshot)  │
│    │    │    ├─ Capture screenshot of each candidate    │
│    │    │    ├─ compareImages() with pixelmatch         │
│    │    │    └─ Return best match (≥70% similarity)     │
│    │    │                                                │
│    │    └─ executeOnCandidate(bestMatch, action)        │
│    │                                                     │
│    └─→ clickAtPosition(x, y)  [Last resort]            │
│         ├─ Add random offset (±2px)                     │
│         ├─ Hover first (100-300ms delay)                │
│         └─ Click                                         │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

## Usage

### Basic Usage

```javascript
import { VisualActionExecutor } from './modules-client/visual-executor.js';
import puppeteer from 'puppeteer-core';

// Launch browser
const browser = await puppeteer.launch({ headless: false });
const page = await browser.newPage();

// Create executor
const executor = new VisualActionExecutor(page);

// Navigate to page
await page.goto('https://example.com');

// Execute recorded action
const action = {
  name: "Click 'Sign In'",
  type: 'click',
  params: {
    visual: {
      screenshot: "data:image/png;base64,...",
      text: "Sign In",
      position: {
        absolute: { x: 150, y: 300 },
        relative: { x: 11.72, y: 41.67 }
      },
      boundingBox: { x: 100, y: 280, width: 100, height: 40 }
    },
    backup_selector: "button.login-btn",
    execution_method: "visual_first"
  }
};

const result = await executor.executeAction(action);

if (result.success) {
  console.log(`✅ Action executed via ${result.method}`);
} else {
  console.error(`❌ Failed: ${result.error}`);
}
```

### Execute Multiple Actions

```javascript
const actions = [
  { type: 'navigate', params: { url: 'https://example.com' } },
  { type: 'click', params: { visual: {...}, backup_selector: '...' } },
  { type: 'type', params: { visual: {...}, text: 'username' } },
  { type: 'wait', params: { duration: 1000 } },
  { type: 'click', params: { visual: {...} } }
];

for (const action of actions) {
  if (action.type === 'navigate') {
    await page.goto(action.params.url);
    continue;
  }
  
  if (action.type === 'wait') {
    await page.waitForTimeout(action.params.duration);
    continue;
  }
  
  const result = await executor.executeAction(action);
  
  if (!result.success) {
    console.error(`Failed on action: ${action.name}`);
    break;
  }
  
  // Wait between actions
  await page.waitForTimeout(1000 + Math.random() * 1000);
}

// Show statistics
console.log('Execution Stats:', executor.getStats());
```

## API Reference

### Constructor

```javascript
new VisualActionExecutor(page)
```

**Parameters:**
- `page` (Puppeteer.Page) - Puppeteer page object

### Methods

#### `executeAction(action)`

Execute a recorded action using visual data.

**Parameters:**
- `action` (Object) - Micro-action with visual data
  - `name` (string) - Action name
  - `type` (string) - Action type (click, type, etc.)
  - `params` (Object)
    - `visual` (Object) - Visual data
    - `backup_selector` (string) - Fallback selector
    - `execution_method` (string) - Preferred method

**Returns:** Promise<Object>
```javascript
{
  success: boolean,
  method: string,  // 'selector', 'visual', 'position', 'error'
  error?: string   // Error message if failed
}
```

**Example:**
```javascript
const result = await executor.executeAction({
  name: "Click 'Login'",
  type: 'click',
  params: {
    visual: { screenshot: '...', text: 'Login', position: {...} },
    backup_selector: 'button.login'
  }
});
```

---

#### `trySelector(action)`

Try to execute action using backup selector.

**Parameters:**
- `action` (Object) - Action with backup_selector

**Returns:** Promise<Object> - Execution result

**Behavior:**
1. Wait for selector (5 seconds timeout)
2. Verify element text matches recorded text
3. Execute action (click or type)
4. Return success or failure

**Example:**
```javascript
const result = await executor.trySelector(action);
if (result.success) {
  console.log('Found by selector!');
}
```

---

#### `findByVisual(action)`

Find element using visual data (text + position + screenshot).

**Parameters:**
- `action` (Object) - Action with visual data

**Returns:** Promise<Object> - Execution result

**Process:**
1. Find all elements with matching text
2. Filter by position (±15% tolerance)
3. If multiple matches, compare screenshots
4. Execute on best match

**Example:**
```javascript
const result = await executor.findByVisual(action);
console.log(`Found by ${result.method}`);
```

---

#### `findByText(text)`

Find elements containing specific text.

**Parameters:**
- `text` (string) - Text to search for

**Returns:** Promise<Array> - Array of candidate elements

**Example:**
```javascript
const candidates = await executor.findByText('Sign In');
console.log(`Found ${candidates.length} candidates`);
```

---

#### `filterByPosition(candidates, targetPosition, tolerance)`

Filter candidates by position proximity.

**Parameters:**
- `candidates` (Array) - Candidate elements
- `targetPosition` (Object) - Target position {x%, y%}
- `tolerance` (number) - Position tolerance percentage (default: 15)

**Returns:** Array - Filtered candidates

**Example:**
```javascript
const nearby = executor.filterByPosition(
  candidates,
  { x: 50, y: 50 },
  15  // ±15%
);
```

---

#### `findBestVisualMatch(candidates, targetScreenshot)`

Find best matching candidate using screenshot comparison.

**Parameters:**
- `candidates` (Array) - Candidate elements
- `targetScreenshot` (string) - Base64 screenshot to match

**Returns:** Promise<Object|null> - Best candidate or null

**Behavior:**
- Captures screenshot of each candidate
- Compares with target using pixelmatch
- Returns candidate with ≥70% similarity
- Returns null if no match above threshold

**Example:**
```javascript
const best = await executor.findBestVisualMatch(
  candidates,
  'data:image/png;base64,...'
);
```

---

#### `compareImages(img1Base64, img2Base64)`

Compare two images and return similarity score.

**Parameters:**
- `img1Base64` (string) - First image (base64 data URL)
- `img2Base64` (string) - Second image (base64 data URL)

**Returns:** Promise<number> - Similarity score 0-1 (1 = identical)

**Process:**
1. Decode base64 images
2. Resize to same dimensions
3. Compare with pixelmatch
4. Calculate similarity percentage

**Example:**
```javascript
const similarity = await executor.compareImages(img1, img2);
if (similarity >= 0.7) {
  console.log('Good match!');
}
```

---

#### `clickAtPosition(x, y)`

Click at specific coordinates with human-like behavior.

**Parameters:**
- `x` (number) - X coordinate
- `y` (number) - Y coordinate

**Returns:** Promise<Object> - Execution result

**Behavior:**
- Adds random offset (±2 pixels)
- Hovers first (100-300ms delay)
- Then clicks

**Example:**
```javascript
await executor.clickAtPosition(150, 300);
```

---

#### `getStats()`

Get execution statistics.

**Returns:** Object
```javascript
{
  selectorSuccess: number,
  textSuccess: number,
  visualSuccess: number,
  positionSuccess: number,
  failures: number,
  total: number,
  successRate: string  // e.g., "95.5%"
}
```

**Example:**
```javascript
const stats = executor.getStats();
console.log(`Success rate: ${stats.successRate}`);
console.log(`Selector: ${stats.selectorSuccess}, Visual: ${stats.visualSuccess}`);
```

---

#### `resetStats()`

Reset execution statistics to zero.

**Example:**
```javascript
executor.resetStats();
```

---

#### `setDebugMode(enabled)`

Enable/disable debug mode (verbose logging).

**Parameters:**
- `enabled` (boolean) - Debug mode enabled

**Example:**
```javascript
executor.setDebugMode(true);
```

## Execution Methods Comparison

| Method | Speed | Robustness | Use Case |
|--------|-------|------------|----------|
| **Selector** | ⚡⚡⚡ Fast (50-200ms) | ⭐ Low | UI unchanged |
| **Text + Position** | ⚡⚡ Medium (200-500ms) | ⭐⭐⭐ Medium | Minor UI changes |
| **Screenshot Match** | ⚡ Slow (500-2000ms) | ⭐⭐⭐⭐ High | Major UI changes |
| **Position Click** | ⚡⚡⚡ Fast (50-100ms) | ⭐⭐ Low | Last resort |

## Position Tolerance

The `filterByPosition()` method uses a **15% tolerance** by default:

```javascript
// Recorded position: x: 50%, y: 50%
// Tolerance: ±15%

// Accepted range:
// x: 35% - 65% (50 ± 15)
// y: 35% - 65% (50 ± 15)

// Examples:
{ x: 50, y: 50 } ✅ Perfect match
{ x: 52, y: 48 } ✅ Within tolerance
{ x: 60, y: 55 } ✅ Within tolerance
{ x: 70, y: 50 } ❌ Outside tolerance (x too far)
{ x: 50, y: 70 } ❌ Outside tolerance (y too far)
```

This tolerance handles:
- Different viewport sizes
- Responsive layouts
- Minor layout shifts
- Scrolling states

## Screenshot Similarity Threshold

The `findBestVisualMatch()` method requires **≥70% similarity**:

```javascript
// Similarity scores:
100% - Pixel-perfect match
90%  - Very close match (minor differences)
80%  - Close match (some differences)
70%  - Acceptable match (threshold) ✅
60%  - Different (rejected) ❌
50%  - Very different (rejected) ❌
```

**What affects similarity:**
- Color changes (button states)
- Icon changes
- Text changes
- Size differences
- Shadow/border changes

## Error Handling

All methods return result objects with error information:

```javascript
// Success
{
  success: true,
  method: 'selector'
}

// Failure with reason
{
  success: false,
  method: 'selector',
  reason: 'text_mismatch'
}

// Error with message
{
  success: false,
  method: 'visual',
  error: 'Element not found by any method'
}
```

**Common errors:**
- `text_mismatch` - Element found but text doesn't match
- `no_text_match` - No elements with matching text
- `no_position_match` - No elements at expected position
- `Element not found by any method` - All methods failed

## Performance Tips

1. **Use execution_method wisely**
   ```javascript
   // Fast path first (if UI is stable)
   execution_method: 'selector_first'
   
   // Robust path (if UI changes frequently)
   execution_method: 'visual_first'
   ```

2. **Adjust position tolerance**
   ```javascript
   // Strict (±10%)
   filterByPosition(candidates, pos, 10)
   
   // Lenient (±20%)
   filterByPosition(candidates, pos, 20)
   ```

3. **Skip screenshot comparison if not needed**
   ```javascript
   // If only one position match, it's used directly
   // Screenshot comparison only runs for multiple matches
   ```

4. **Batch actions**
   ```javascript
   // Execute multiple actions without reloading page
   for (const action of actions) {
     await executor.executeAction(action);
     await page.waitForTimeout(1000); // Wait between actions
   }
   ```

## Troubleshooting

### Problem: Selector method always fails
**Solution**: Selectors may have changed. Rely on visual method.

### Problem: No text matches found
**Solution**: Check if text changed. Use partial text or update recording.

### Problem: Position matches but screenshot fails
**Solution**: UI styling changed. Lower similarity threshold or rely on position.

### Problem: All methods fail
**Solution**: Element may not exist or page structure completely changed. Re-record action.

## Next Steps

Phase 5 will add:
- OCR-based text extraction (tesseract.js)
- Fuzzy text matching (fuse.js)
- AI-powered element detection
- Visual regression testing
